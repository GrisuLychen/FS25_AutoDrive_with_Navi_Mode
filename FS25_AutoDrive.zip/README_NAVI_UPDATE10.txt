Navi Update 10

Changes:
- straight maneuvers are no longer shown as text; only the next real turn is displayed
- active turn stays locked until a dedicated exit point behind the junction is passed
- distance display now uses a stable direct distance to the active maneuver point and is clamped to avoid jumping up
- rerouting is more sluggish, especially in junction zones
- navigation tuning parameters moved to scripts/Modes/NavigationConfig.lua
