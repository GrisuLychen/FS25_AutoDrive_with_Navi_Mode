FS25 AutoDrive Navi Update 8

Änderungen:
- Manövererkennung jetzt nur noch an echten Entscheidungsknoten/Kreuzungen
- Richtungsbewertung über geglättete Fahrtrichtung vor und nach der Kreuzung
- Vergleich mit den möglichen Ausfahrten am Knoten, um Geradeaus besser von echtem Abbiegen zu trennen
- Manöver-Lock bis zum tatsächlichen Passieren des Knotens
- Träges Re-Routing in Kreuzungsnähe und bei leichtem Spurversatz
- "Bitte wenden" erst bei klarer Gegenrichtung + rückläufigem Fortschritt auf der Route
- Manöver werden erst innerhalb von ca. 200 m vor der Kreuzung eingeblendet; davor "Geradeaus"

Incremental:
- scripts/Modes/NavigationMode.lua

Fullpatch:
- enthält weiterhin den kompletten Patch-Stand gegenüber dem Original-Mod aus den vorherigen Updates
