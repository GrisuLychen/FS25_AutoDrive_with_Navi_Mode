FS25 AutoDrive Navi Update 5

Änderungen gegenüber Update 4:
- Links/Rechts-Zuordnung korrigiert
- Manöverklassen auf Geradeaus / Links / Rechts / Scharf links / Scharf rechts umgestellt
- Balkenanzeige zeigt nur noch die Distanz bis zur nächsten echten Abbiegung, nicht bis Geradeaus-Manövern
- Distanz in Metern zusätzlich zur Balkenanzeige eingeblendet
- HUD-Text größer und rot eingefärbt
- Navi-Routenlinie deutlich dicker gezeichnet
- Manöver-Lock enger gesetzt, damit erst nach Erreichen des Punktes weitergesprungen wird
