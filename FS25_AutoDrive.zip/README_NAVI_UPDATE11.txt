FS25 AutoDrive Navi Update 11

Changes:
- fixed left/right assignment again
- active maneuver now counts down along the route and, after reaching the turn node,
  continues to count down to the maneuver exit point instead of getting stuck at 0 m
- projection lock past the exit is released once the maneuver node is effectively reached,
  so the old maneuver can complete and the next one can appear
- reroute thresholds and delays made more conservative in NavigationConfig.lua

Files included:
- scripts/Modes/NavigationMode.lua
- scripts/Modes/NavigationConfig.lua
