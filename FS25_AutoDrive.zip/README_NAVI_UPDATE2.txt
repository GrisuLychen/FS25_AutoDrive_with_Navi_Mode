FS25 AutoDrive Navi Update 2

Enthaltene Anpassungen:
- ruhigere Distanzberechnung durch Projektion auf die Route
- Erkennung von echten Fahrmanoevern statt kleiner Knicke
- zweite Vorschauzeile fuer das naechste Abbiegen ("Dann: ...")

Installation:
- Inhalt dieser ZIP in die bereits gepatchte FS25_AutoDrive-Mod kopieren und vorhandene Dateien ersetzen.
