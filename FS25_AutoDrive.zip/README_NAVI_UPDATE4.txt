Navi Update 4

Enthaelt:
- rote, deutlich dickere Navi-Routenlinie
- Manoever-Erkennung am naechsten Kreuzungs-/Entscheidungspunkt
- neue Richtungen: halb links / halb rechts
- Balkenanzeige statt unzuverlaessiger Meter zum naechsten Manoever
- vorsichtigeres Re-Routing; eher Bitte wenden statt sofort neu rechnen
