FS25 AutoDrive Navi Update 12

Änderungen gegenüber Update 11:
- Links/Rechts-Zuordnung erneut korrigiert
- aktives Manöver bleibt länger an Knoten/Ausfahrt gebunden
- Distanzanzeige wird pro Tick nur noch plausibel abgesenkt/angehoben
- Projektion auf die Route wird vor dem aktiven Manöver stärker begrenzt
- Neuberechnung in Kreuzungsnähe deutlich träger gemacht
- neue Parameter in scripts/Modes/NavigationConfig.lua für:
  * decisionZoneDistance
  * decisionHoldAfterExit
  * activeManeuverExitHold
  * rerouteDistanceBase
  * rerouteDistanceIntersection
  * rerouteDistanceIntersectionHard
  * rerouteDelayMs
  * wrongWayDelayMs
  * distance display smoothing

Incremental-Paket überschreibt:
- scripts/Modes/NavigationMode.lua
- scripts/Modes/NavigationConfig.lua
