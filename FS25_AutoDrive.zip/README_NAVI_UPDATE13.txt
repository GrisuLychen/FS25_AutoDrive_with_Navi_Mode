FS25 AutoDrive Navi Update 13

Enthalten:
- Korrektur Links/Rechts-Zuordnung
- stabilere Distanzanzeige zum aktiven Manöver
- kein Umschalten der Meterzahl auf den Kreuzungs-Ausgangspunkt
- aktives Manöver bleibt weiterhin bis zum Kreuzungs-Ausgangspunkt gelockt
- neue Konfig-Option fuer zulässigen Distanzanstieg pro Tick beim selben Manöver

Dateien im Incremental:
- scripts/Modes/NavigationMode.lua
- scripts/Modes/NavigationConfig.lua
- README_NAVI_UPDATE13.txt
