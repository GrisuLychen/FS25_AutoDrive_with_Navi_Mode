AutoDrive Navi Update 9
=======================

Enthaltene Änderungen:
- Links/Rechts-Zuordnung korrigiert
- Manöver bleiben bis zu einem definierten Kreuzungs-Ausgangspunkt aktiv
- Re-Routing an Kreuzungen träger / mit größerer Toleranz
- Navi-Parameter in scripts/Modes/NavigationConfig.lua ausgelagert

Wichtige Parameter:
- decisionZoneDistance
- intersectionExitLockDistance
- rerouteDistanceBase
- rerouteDistanceIntersection
- rerouteDistanceIntersectionHard
- rerouteDelayMs
- wrongWayHeadingDeg
- wrongWayDelayMs

Dateien im Incremental:
- register.lua
- scripts/Modes/NavigationConfig.lua
- scripts/Modes/NavigationMode.lua
