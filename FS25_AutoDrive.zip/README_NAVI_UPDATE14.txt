Update 14
- Soft route refresh is blocked while an active maneuver is still pending close ahead.
- Maneuver distance uses vehicle->next route point + remaining route segments to the maneuver point.
- Distance display is clamped to avoid visible rises within the same maneuver.
- Reroute defaults are more conservative and easier to tune in scripts/Modes/NavigationConfig.lua.
