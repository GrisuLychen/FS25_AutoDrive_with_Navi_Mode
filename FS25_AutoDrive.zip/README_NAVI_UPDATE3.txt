FS25 AutoDrive Navi Update 3

Enthaltene Änderungen:
- Sichtbare Routen-Vorschau der nächsten geplanten Wegabschnitte im Navi-Modus
- Distanzberechnung entlang der gespeicherten Route statt über springende Zwischenpunkte
- Stabilere Abbiege-Erkennung mit Lock auf das nächste Manöver
- Vorsichtige "Bitte wenden"-Logik bei klarer Falschfahrt gegen den Routenverlauf

Installation:
- ZIP entpacken
- Dateien in die bereits gepatchte AutoDrive-Version kopieren und überschreiben
